<?php
/**
 * Plugin Name: wpsync-webspark
 * Description: Product synchronization plugin via API.
 * Author:      Ivan Peshko
 * Version:     1.0
 */


//Helpers functions for add Product
// Custom function for product creation
function create_product( $args ) {

	if ( ! function_exists( 'wc_get_product_object_type' ) && ! function_exists( 'wc_prepare_product_attributes' ) ) {
		return false;
	}

	// Get an empty instance of the product object (defining it's type)
	$product = wc_get_product_object_type( $args['type'] );
	if ( ! $product ) {
		return false;
	}

	// Product name (Title) and slug
	$product->set_name( $args['name'] ); // Name (title).
	if ( isset( $args['slug'] ) ) {
		$product->set_name( $args['slug'] );
	}

	// Description and short description:
	$product->set_description( $args['description'] );
	$product->set_short_description( $args['short_description'] );

	// Status ('publish', 'pending', 'draft' or 'trash')
	$product->set_status( isset( $args['status'] ) ? $args['status'] : 'publish' );

	// Visibility ('hidden', 'visible', 'search' or 'catalog')
	$product->set_catalog_visibility( isset( $args['visibility'] ) ? $args['visibility'] : 'visible' );

	// Featured (boolean)
	$product->set_featured( isset( $args['featured'] ) ? $args['featured'] : false );

	// Virtual (boolean)
	$product->set_virtual( isset( $args['virtual'] ) ? $args['virtual'] : false );

	// Prices
	$product->set_regular_price( $args['regular_price'] );
	$product->set_sale_price( isset( $args['sale_price'] ) ? $args['sale_price'] : '' );
	$product->set_price( isset( $args['sale_price'] ) ? $args['sale_price'] : $args['regular_price'] );
	if ( isset( $args['sale_price'] ) ) {
		$product->set_date_on_sale_from( isset( $args['sale_from'] ) ? $args['sale_from'] : '' );
		$product->set_date_on_sale_to( isset( $args['sale_to'] ) ? $args['sale_to'] : '' );
	}

	// Downloadable (boolean)
	$product->set_downloadable( isset( $args['downloadable'] ) ? $args['downloadable'] : false );
	if ( isset( $args['downloadable'] ) && $args['downloadable'] ) {
		$product->set_downloads( isset( $args['downloads'] ) ? $args['downloads'] : array() );
		$product->set_download_limit( isset( $args['download_limit'] ) ? $args['download_limit'] : '-1' );
		$product->set_download_expiry( isset( $args['download_expiry'] ) ? $args['download_expiry'] : '-1' );
	}

	// Taxes
	if ( get_option( 'woocommerce_calc_taxes' ) === 'yes' ) {
		$product->set_tax_status( isset( $args['tax_status'] ) ? $args['tax_status'] : 'taxable' );
		$product->set_tax_class( isset( $args['tax_class'] ) ? $args['tax_class'] : '' );
	}

	// SKU and Stock (Not a virtual product)
	$product->set_sku( isset( $args['sku'] ) ? $args['sku'] : '' );
	$product->set_manage_stock( isset( $args['manage_stock'] ) ? $args['manage_stock'] : false );
	$product->set_stock_status( isset( $args['stock_status'] ) ? $args['stock_status'] : 'instock' );
	$product->set_stock_quantity( $args['stock_qty'] );

	// Sold Individually
	$product->set_sold_individually( isset( $args['sold_individually'] ) ? $args['sold_individually'] : false );

	// Weight, dimensions and shipping class
	$product->set_weight( isset( $args['weight'] ) ? $args['weight'] : '' );
	$product->set_length( isset( $args['length'] ) ? $args['length'] : '' );
	$product->set_width( isset( $args['width'] ) ? $args['width'] : '' );
	$product->set_height( isset( $args['height'] ) ? $args['height'] : '' );
	if ( isset( $args['shipping_class_id'] ) ) {
		$product->set_shipping_class_id( $args['shipping_class_id'] );
	}

	// Upsell and Cross sell (IDs)
	$product->set_upsell_ids( isset( $args['upsells'] ) ? $args['upsells'] : '' );
	$product->set_cross_sell_ids( isset( $args['cross_sells'] ) ? $args['upsells'] : '' );

	// Attributes et default attributes
	if ( isset( $args['attributes'] ) ) {
		$product->set_attributes( wc_prepare_product_attributes( $args['attributes'] ) );
	}
	if ( isset( $args['default_attributes'] ) ) {
		$product->set_default_attributes( $args['default_attributes'] );
	} // Needs a special formatting

	// Reviews, purchase note and menu order
	$product->set_reviews_allowed( isset( $args['reviews'] ) ? $args['reviews'] : false );
	$product->set_purchase_note( isset( $args['note'] ) ? $args['note'] : '' );
	if ( isset( $args['menu_order'] ) ) {
		$product->set_menu_order( $args['menu_order'] );
	}

	// Product categories and Tags
	if ( isset( $args['category_ids'] ) ) {
		$product->set_category_ids( $args['category_ids'] );
	}
	if ( isset( $args['tag_ids'] ) ) {
		$product->set_tag_ids( $args['tag_ids'] );
	}


	// Images and Gallery
	$product->set_image_id( isset( $args['image_id'] ) ? $args['image_id'] : "" );
	$product->set_gallery_image_ids( isset( $args['gallery_ids'] ) ? $args['gallery_ids'] : array() );

	## --- SAVE PRODUCT --- ##
	$product_id = $product->save();

	return $product_id;
}

// Utility function that returns the correct product object instance
function wc_get_product_object_type( $type ) {
	// Get an instance of the WC_Product object (depending on his type)
	if ( isset( $args['type'] ) && $args['type'] === 'variable' ) {
		$product = new WC_Product_Variable();
	} elseif ( isset( $args['type'] ) && $args['type'] === 'grouped' ) {
		$product = new WC_Product_Grouped();
	} elseif ( isset( $args['type'] ) && $args['type'] === 'external' ) {
		$product = new WC_Product_External();
	} else {
		$product = new WC_Product_Simple(); // "simple" By default
	}

	if ( ! is_a( $product, 'WC_Product' ) ) {
		return false;
	} else {
		return $product;
	}
}

// Utility function that prepare product attributes before saving
function wc_prepare_product_attributes( $attributes ) {
	global $woocommerce;

	$data     = array();
	$position = 0;

	foreach ( $attributes as $taxonomy => $values ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			continue;
		}

		// Get an instance of the WC_Product_Attribute Object
		$attribute = new WC_Product_Attribute();

		$term_ids = array();

		// Loop through the term names
		foreach ( $values['term_names'] as $term_name ) {
			if ( term_exists( $term_name, $taxonomy ) ) // Get and set the term ID in the array from the term name
			{
				$term_ids[] = get_term_by( 'name', $term_name, $taxonomy )->term_id;
			} else {
				continue;
			}
		}

		$taxonomy_id = wc_attribute_taxonomy_id_by_name( $taxonomy ); // Get taxonomy ID

		$attribute->set_id( $taxonomy_id );
		$attribute->set_name( $taxonomy );
		$attribute->set_options( $term_ids );
		$attribute->set_position( $position );
		$attribute->set_visible( $values['is_visible'] );
		$attribute->set_variation( $values['for_variation'] );

		$data[ $taxonomy ] = $attribute; // Set in an array

		$position ++; // Increase position
	}

	return $data;
}

//Utility function for get product by SKU
function iconic_get_product_id_by_sku( $sku = false ) {

	global $wpdb;

	if ( ! $sku ) {
		return null;
	}

	$product_id = $wpdb->get_var(
		$wpdb->prepare( "SELECT post_id FROM $wpdb->postmeta WHERE meta_key='_sku' AND meta_value='%s' LIMIT 1",
			$sku )
	);

	if ( $product_id ) {
		return $product_id;
	}

	return null;

}

//Add image to media WP for set to product
function generate_featured_image( $image_url, $post_id ) {
	$upload_dir        = wp_upload_dir();
	$arrContextOptions = array(
		"ssl" => array(
			"verify_peer"      => false,
			"verify_peer_name" => false,
		),
	);
	$image_data        = file_get_contents( $image_url, false, stream_context_create( $arrContextOptions ) );
	$filename          = basename( $image_url );
	if ( wp_mkdir_p( $upload_dir['path'] ) ) {
		$file = $upload_dir['path'] . '/' . $filename;
	} else {
		$file = $upload_dir['basedir'] . '/' . $filename;
	}
	file_put_contents( $file, $image_data );

	$wp_filetype = wp_check_filetype( $filename, null );
	$attachment  = array(
		'post_mime_type' => $wp_filetype['type'],
		'post_title'     => sanitize_file_name( $filename ),
		'post_content'   => '',
		'post_status'    => 'inherit'
	);
	$attach_id   = wp_insert_attachment( $attachment, $file, $post_id );
	require_once( ABSPATH . 'wp-admin/includes/image.php' );
	$attach_data = wp_generate_attachment_metadata( $attach_id, $file );
	$res1        = wp_update_attachment_metadata( $attach_id, $attach_data );
	$res2        = set_post_thumbnail( $post_id, $attach_id );
	update_post_meta( $post_id, '_product_image_gallery', $attach_id );
}

//Get product attachments
function get_attachments_post( $post_id = 0 ) {
	$args = array(
		'post_parent'    => $post_id,
		'post_type'      => 'attachment',
		'post_mime_type' => 'image',
		'posts_per_page' => - 1,
	);

	if ( $attachments = get_children( $args ) ) {
		return $attachments;
	}

	return [];
}

//Delete product function
function wc_my_delete_product( $id, $force = false ) {
	$product     = wc_get_product( $id );
	$attachments = get_attachments_post( $id );

	//Delete product images
	if ( $attachments ) {
		foreach ( $attachments as $attachment ) {
			wp_delete_attachment( $attachment->ID, $force );
		}
	}

	if ( empty( $product ) ) {
		return new WP_Error( 999, sprintf( __( 'No %s is associated with #%d', 'woocommerce' ), 'product', $id ) );
	}

	// If we're forcing, then delete permanently.
	if ( $force ) {
		if ( $product->is_type( 'variable' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				$child->delete( true );
			}
		} elseif ( $product->is_type( 'grouped' ) ) {
			foreach ( $product->get_children() as $child_id ) {
				$child = wc_get_product( $child_id );
				$child->set_parent_id( 0 );
				$child->save();
			}
		}

		$product->delete( true );
		$result = $product->get_id() > 0 ? false : true;
	} else {
		$product->delete();
		$result = 'trash' === $product->get_status();
	}

	if ( ! $result ) {
		return new WP_Error( 999, sprintf( __( 'This %s cannot be deleted', 'woocommerce' ), 'product' ) );
	}

	// Delete parent product transients.
	if ( $parent_id = wp_get_post_parent_id( $id ) ) {
		wc_my_delete_product_transients( $parent_id );
	}

	return true;
}


register_activation_hook( __FILE__, 'my_activation' );
function my_activation() {
	// just in case, delete all the same cron tasks to add new ones from a "clean slate"
	// this may be necessary if the same task was previously connected incorrectly (without checking that it already exists)
	wp_clear_scheduled_hook( 'api_import' );

	// add a new cron job
	wp_schedule_event( time(), 'hourly', 'api_import' );
}

// Check if the cron is running, if not, do nothing
if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
	add_action( 'api_import', 'hourly_import' );
	function hourly_import() {
		//$products = ( json_decode( wp_remote_retrieve_body( wp_remote_get( 'https://my.api.mockaroo.com/products.json?key=89b23a40' ) ), true ) );
		$products = json_decode( file_get_contents( 'http://test.local/products.json' ), true );

		//Check if API don`t return anything and check DB limit
		if ( count( $products ) == 0 || count( $products ) > 10000 ) {
			exit();
		}

		//Get current product ids for future check
		$current_site_products = new WC_Product_Query( array(
			'limit'   => - 1,
			'orderby' => 'date',
			'order'   => 'DESC',
			'return'  => 'ids',
		) );
		$current_site_products = $current_site_products->get_products();

		foreach ( $products as $product ) {

			//Data Corrections
			$correct_price       = str_replace( '$', '', $product['price'] );
			$correct_picture_url = $product['picture'] . '.jpg';

			//check is product already exist
			$is_exist = iconic_get_product_id_by_sku( $product['sku'] );

			if ( $is_exist ) {
				$products_needs_in_site_ids[] = $is_exist;
				$exist_product                = wc_get_product( $is_exist );

				if ( $exist_product->get_name() !== $product['name'] ) {
					$exist_product->set_name( $product['name'] );
				}

				if ( $exist_product->get_description() !== $product['description'] ) {
					$exist_product->set_description( $product['description'] );
				}

				if ( $exist_product->get_price( 'edit' ) !== $correct_price ) {
					$exist_product->set_regular_price( $correct_price );
				}

				if ( $exist_product->get_stock_quantity( 'edit' ) !== $product['in_stock'] ) {
					$exist_product->set_stock_quantity( $product['in_stock'] );
				}

				$exist_product->save();

				//Delete product images and load new
				//because checking by size and pixels will heavily load the system, and checking by name may not work correctly
				$attachments = get_attachments_post( $is_exist );
				if ( $attachments ) {
					foreach ( $attachments as $attachment ) {
						wp_delete_attachment( $attachment->ID, true );
					}
				}
				generate_featured_image( $correct_picture_url, $is_exist );

			} else {
				$product_id = create_product( array(
					'type'              => '', // Simple product by default
					'name'              => $product['name'],
					'description'       => $product['description'],
					'short_description' => '',
					'sku'               => $product['sku'],
					'regular_price'     => $correct_price, // product price
					'manage_stock'      => true,
					'stock_status'      => 'instock',
					'stock_qty'         => $product['in_stock'],
					'reviews_allowed'   => true,
					'status'            => 'publish',
					'category_ids'      => array(),

				) );

				generate_featured_image( $correct_picture_url, $product_id );
			}

		}

		//Delete Products that not in list
		$products_to_delete = array_diff( $current_site_products, $products_needs_in_site_ids );
		foreach ( $products_to_delete as $product_id ) {
			wc_my_delete_product( $product_id, true );
		}
	}
}

// When deactivating the plugin or in other cases, delete the previously created task:
register_deactivation_hook( __FILE__, 'my_deactivation' );
function my_deactivation() {
	wp_clear_scheduled_hook( 'api_import' );
}
